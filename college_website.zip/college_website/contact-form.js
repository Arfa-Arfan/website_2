
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('contactForm');
    const submitBtn = document.getElementById('submitBtn');
    const formMessage = document.getElementById('formMessage');

    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const subject = document.getElementById('subject').value.trim();
            const message = document.getElementById('message').value.trim();
            if (!name || !email || !subject || !message) {
                showMessage('Please fill in all fields.', 'error');
                return;
            }

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                showMessage('Please enter a valid email address.', 'error');
                return;
            }
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Sending...';
            submitBtn.disabled = true;
            formMessage.style.display = 'none';
            if (typeof emailjs !== 'undefined') {
                const serviceID = 'YOUR_SERVICE_ID';
                const templateID = 'YOUR_TEMPLATE_ID';
                if (serviceID !== 'YOUR_SERVICE_ID' && templateID !== 'YOUR_TEMPLATE_ID') {
                    emailjs.send(serviceID, templateID, {
                        from_name: name,
                        from_email: email,
                        subject: subject,
                        message: message,
                        to_email: 'info@easytutorialspro.com'
                    })
                    .then(function(response) {
                        showMessage('Message sent successfully! We will get back to you soon.', 'success');
                        form.reset();
                        submitBtn.textContent = originalText;
                        submitBtn.disabled = false;
                    }, function(error) {
                        console.error('EmailJS Error:', error);
                        sendViaMailto(name, email, subject, message, originalText);
                    });
                } else {
                    sendViaMailto(name, email, subject, message, originalText);
                }
            } else {
                sendViaMailto(name, email, subject, message, originalText);
            }
        });
    }

    function sendViaMailto(name, email, subject, message, originalText) {
        const emailBody = `Name: ${name}\nEmail: ${email}\n\nSubject: ${subject}\n\nMessage:\n${message}`;
        const mailtoLink = `mailto:info@easytutorialspro.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(emailBody)}`;
        window.location.href = mailtoLink;
        setTimeout(function() {
            showMessage('Your email client should open. If it doesn\'t, please email us directly at info@easytutorialspro.com', 'info');
            submitBtn.textContent = originalText;
            submitBtn.disabled = false;
        }, 500);
    }

    function showMessage(text, type) {
        formMessage.textContent = text;
        formMessage.style.display = 'block';
        formMessage.style.padding = '15px';
        formMessage.style.borderRadius = '5px';
        formMessage.style.marginTop = '20px';
        
        if (type === 'success') {
            formMessage.style.backgroundColor = '#d4edda';
            formMessage.style.color = '#155724';
            formMessage.style.border = '1px solid #c3e6cb';
        } else if (type === 'error') {
            formMessage.style.backgroundColor = '#f8d7da';
            formMessage.style.color = '#721c24';
            formMessage.style.border = '1px solid #f5c6cb';
        } else {
            formMessage.style.backgroundColor = '#d1ecf1';
            formMessage.style.color = '#0c5460';
            formMessage.style.border = '1px solid #bee5eb';
        }
        submitBtn.textContent = 'Send Message';
        submitBtn.disabled = false;
    
        setTimeout(function() {
            formMessage.style.display = 'none';
        }, 5000);
    }
});

